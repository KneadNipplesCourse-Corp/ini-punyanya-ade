import 'package:flutter/material.dart';
import 'package:ade_restapi/controller/product_controller.dart';
import 'package:ade_restapi/login.dart';
import 'package:ade_restapi/middleware/auth_middleware.dart';
import 'package:ade_restapi/products.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Pastikan Flutter binding terinisialisasi
  await GetStorage.init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // ProductController harus diinisialisasi sekali saja dan diakses oleh Get.find() di tempat lain
  // Untuk rute awal, kita perlu memastikan GetStorage sudah siap sebelum middleware berjalan.
  // Sebaiknya controller di-put() saat dibutuhkan atau diinisialisasi via binding jika rumit.
  // Untuk kasus ini, karena controller juga digunakan untuk inisialisasi isLoggedIn,
  // mem-put di sini masih OK.
  final ProductController controller = Get.put(ProductController());

  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false, // Hide debug banner
      title: 'YAHYA SHOES', // App title
      theme: ThemeData(
        primarySwatch: Colors.deepPurple, // Primary color for the app
        visualDensity: VisualDensity.adaptivePlatformDensity,
        appBarTheme: const AppBarTheme(
          color: Colors.deepPurple, // Default AppBar color
          foregroundColor: Colors.white, // Default AppBar text/icon color
          elevation: 4,
          iconTheme: IconThemeData(color: Colors.white),
        ),
      ),
      // Awalnya, kita biarkan middleware yang menentukan rute awal
      // Jika token ada, middleware akan membiarkannya ke /products.
      // Jika token tidak ada, middleware akan me-redirect ke /login.
      initialRoute: "/products", // Middleware akan mengecek ini
      getPages: [
        GetPage(name: "/login", page: () => LoginPage()),
        GetPage(
          name: "/products",
          page: () => ProductPage(),
          middlewares: [AuthMiddleware()],
          // binding: BindingsBuilder(() { // Opsional: binding spesifik untuk ProductsPage
          //   Get.lazyPut<ProductController>(() => ProductController());
          // }),
        ),
      ],
    );
  }
}